document.addEventListener("DOMContentLoaded", function () {
    const productNameElement = document.getElementById("productName");
    const productForm = document.getElementById("productForm");
    const totalPriceElement = document.getElementById("totalPrice");
  
    let selectedProduct = {
      name: "Pastel delicioso",
      size: "",
      delivery: 0,
      price: 0,
    };
  
    function updateTotalPrice() {
      const total = selectedProduct.price + selectedProduct.delivery;
      totalPriceElement.textContent = total;
    }
  
    productForm.addEventListener("change", function (event) {
      const target = event.target;
  
      if (target.name === "size") {
        selectedProduct.size = target.value;
        selectedProduct.price = parseInt(target.getAttribute("data-price"));
      }
  
      if (target.id === "delivery") {
        selectedProduct.delivery = target.checked ? parseInt(target.value) : 0;
      }
  
      updateTotalPrice();
    });
  
    const addToCartButton = document.getElementById("addToCart");
  
    addToCartButton.addEventListener("click", function () {
      const productInfoContainer = document.getElementById("productInfo");
  
      const productInfoHTML = `
        <p>Producto: ${selectedProduct.name}</p>
        <p>Tamaño: ${selectedProduct.size}</p>
        <p>Precio: ${selectedProduct.price} soles</p>
        <p>Precio de entrega: ${selectedProduct.delivery} soles</p>
        <p>Precio Total: ${selectedProduct.price + selectedProduct.delivery} soles</p>
      `;
  
      productInfoContainer.innerHTML = productInfoHTML;
    });
  });