  // regresar historial

  document.addEventListener("DOMContentLoaded", function () {
	const goBackButton = document.getElementById("go-back");
  
	goBackButton.addEventListener("click", function () {
	  window.history.back(); // Retrocede una página en el historial del navegador
	});
  
	// Resto de tu código...
  });