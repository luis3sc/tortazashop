
// MENU > ICONO BUSCAR
const triggerOpen = document.querySelectorAll('[trigger-button]');
const triggerClose = document.querySelectorAll('[close-button]');
const overlay = document.querySelector('[data-overlay]');

for (let i = 0; i < triggerOpen.length; i++){
    let currentId = triggerOpen[i].dataset.target,
    targetEl = document.querySelector(`#${currentId}`)
    
    const openData = function() {
        targetEl.classList.remove('active');
        overlay.classList.remove('active');
    };
    triggerOpen[i].addEventListener('click', function(){
        targetEl.classList.add('active');
        overlay.classList.add('active');
    });

    targetEl.querySelector('[close-button]').addEventListener('click', openData);
    overlay.addEventListener('click', openData)
}
//mobile-menu submenu categoria
const submenu = document.querySelectorAll('.child-trigger');
submenu.forEach((menu) => menu.addEventListener('click', function(e) {
    e.preventDefault();
    submenu.forEach((item) => item != this ? item.closest('.has-child').classList.remove('active') : null);
    if(this.closest('.has-child').classList != 'active'){
        this.closest('.has-child').classList.toggle('active');
    }    
}))


function mostrarModal(modal){
	//Oferta
	if(modal === 1){
		$("#modalPromocion").fadeIn();
	}
	//Compartir
	if(modal === 2){
		$("#modalCompartir").fadeIn();
	}
	//Ubicacion
	if(modal === 3){
		$("#modalUbicacion").fadeIn();
	}
	//Contactar
	if(modal === 4){
		$("#modalContacto").fadeIn();
	}
	//Pagos
	if(modal === 5){
		$("#modalPagos").fadeIn();
	}
	//Redes Sociales
	if(modal === 6){
		$("#modalRedes").fadeIn();
	}
	//Formulario Reserva
	if(modal === 7){
		$("#modalReserva").fadeIn();
	}
	//Registrar Cuenta
	if(modal === 8){
		$("#modalRegistrarCuenta").fadeIn();
	}
	//Registrar Login
	if(modal === 9){
		$("#modalLogin").fadeIn();
	}
	//Registrar QR
	if(modal === 10){
		$("#modalMiqr").fadeIn();
	}
	//Registrar Cuenta
	if(modal === 11){
		$("#modalWhastapp").fadeIn();
	}
	//Servicios
	if(modal === 12){
		$("#modalServicios").fadeIn();
	}
	//Nosotros
	if(modal === 13){
		$("#modalNosotros").fadeIn();
	}
	//Tienda
	if(modal === 14){
		$("#modalTienda").fadeIn();
	}
	//Cartilla de Sellos
	if(modal === 15){
		$("#modalSellos").fadeIn();
	}
	//Mis Reservas
	if(modal === 16){
		$("#modalReservas").fadeIn();
	}
	//Carta
	if(modal === 17){
		$("#modalCarta").fadeIn();
	}
	//Torneo
	if(modal === 18){
		$("#modalTorneo").fadeIn();
	}
	//MiPuntos
	if(modal === 19){
		$("#modalPuntos").fadeIn();
	}
	//MisMisiones
	if(modal === 20){
		$("#modalMisiones").fadeIn();
	}
	//MisReferral
	if(modal === 21){
		$("#modalReferral").fadeIn();
	}
	//TiendaVIP
	if(modal === 22){
		$("#modalTiendavip").fadeIn();
	}
	//Carta
	if(modal === 23){
		$("#modalOtorgar").fadeIn();
	}

}

function cerrarmodal(){
    $('.modal').fadeOut();
}

  /// VARIACIONES DE PRECIO //
  let cakePrice = 0;
  let quantity = 1;

  function updatePrice(size) {
    switch (size) {
      case 8:
        cakePrice = 20;
        break;
      case 10:
        cakePrice = 30;
        break;
      case 12:
        cakePrice = 40;
        break;
      case 14:
        cakePrice = 50;
        break;
      default:
        cakePrice = 0;
        break;
    }

    updateTotal();
  }

  function updateTotal() {
    //const deliveryCheckbox = document.getElementById("delivery");
    //const deliveryPrice = deliveryCheckbox.checked ? 5 : 0;
    const totalPrice = cakePrice  * quantity;

    const priceDisplay = document.getElementById("price-display");
    priceDisplay.textContent = `Precio de la torta: S/ ${cakePrice}`;

    //const deliveryDisplay = document.getElementById("delivery-display");
    //deliveryDisplay.textContent = `Costo de Entrega: S/ ${deliveryPrice}`;

    const totalDisplay = document.getElementById("total-display");
    totalDisplay.textContent = `S/ ${totalPrice}`;
  }

  function incrementQuantity() {
    quantity++;
    document.getElementById("quantity").value = quantity;
    updateTotal();
  }

  function decrementQuantity() {
    if (quantity > 1) {
      quantity--;
      document.getElementById("quantity").value = quantity;
      updateTotal();
    }
  }





	
	
	

