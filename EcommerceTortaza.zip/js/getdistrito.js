const modal = document.getElementById('modal');
        const nextStepBtn1 = document.getElementById('nextStepBtn1');
        const nextStepBtn2 = document.getElementById('nextStepBtn2');
        const locationMessage = document.getElementById('locationMessage');
        const locationOptions = document.getElementById('locationOptions');
        const customMessage = document.getElementById('customMessage');
        const resultadoPersonalizado = document.getElementById('resultadoPersonalizado');
        const deliveryTypeRadios = document.querySelectorAll('input[name="deliveryType"]');
        let selectedDeliveryType = sessionStorage.getItem('selectedDeliveryType');
        let selectedLocation = sessionStorage.getItem('selectedLocation');
        let acceptBtn; // Declaración de la variable
        let currentStep = 1; // Iniciar en el paso 1

         // Función para mostrar el paso actual
         function showStep(stepNumber) {
            const steps = document.querySelectorAll('.step');
            steps.forEach(step => step.classList.remove('active'));
            steps[stepNumber - 1].classList.add('active');
        }


        nextStepBtn1.addEventListener('click', () => {
            selectedDeliveryType = Array.from(deliveryTypeRadios).find(radio => radio.checked).value;
            sessionStorage.setItem('selectedDeliveryType', selectedDeliveryType);
            showStep(2);
            if (selectedDeliveryType === 'delivery') {
                locationMessage.innerHTML = `
                <h2>Cobertura del delivery</h2> 
                <p>Selecciona el distrito en que te encuentras:</p>
                <p>solo tenemos cobertura en estos distritos</p>
                `;
                locationOptions.innerHTML = `
                <div class="radio-toolbar flex-w gap-5 mgtp">
                    
                    <input type="radio" id="ate" name="location" value="ate">
                    <label for="ate"><h4>Ate</h4></label>

                    <input type="radio" id="lamolina" name="location" value="la molina">
                    <label for="lamolina"><h4>La Molina</h4></label>

                    <input type="radio" id="salamanca" name="location" value="salamanca">
                    <label for="salamanca"><h4>Salamanca</h4></label> 

                    <input type="radio" id="sanborja" name="location" value="san borja">
                    <label for="sanborja"><h4>San Borja</h4></label>

                    <input type="radio" id="surco" name="location" value="surco">
                    <label for="surco"><h4>Surco</h4></label>

                    <input type="radio" id="sanluis" name="location" value="san luis">
                    <label for="sanluis"><h4>San Luis</h4></label>

                    <input type="radio" id="chaclacayo" name="location" value="chaclacayo">
                    <label for="chaclacayo"><h4>Chaclacayo</h4></label>

                    <input type="radio" id="santaanita" name="location" value="santa anita">
                    <label for="santaanita"><h4>Santa Anita</h4></label>

                    <input type="radio" id="elagustino" name="location" value="el agustino">
                    <label for="elagustino"><h4>El Agustino</h4></label>

                    <input type="radio" id="chosica" name="location" value="chosica">
                    <label for="chosica"><h4>Lurigancho - Chosica</h4></label>

                    <input type="radio" id="none" name="location" value="none"> 
                    <label for="none"><h4>No se encuentra mi distrito</h4></label>
                </div>    
                `;
            } else if (selectedDeliveryType === 'tienda') {
                locationMessage.textContent = 'Selecciona una tienda para recoger:';
                locationOptions.innerHTML = `

                <div class="radio-toolbar flex-w gap-5 mgtp">

                    <input type="radio" id="ceres" name="location" value="Ceres">
                    <label class="w100" for="ceres">
                    <h4>Tienda Ceres</h4>
                        <div class="flex-row gap-5">
                            <i class="ri-map-pin-line"></i>
                            <p>Av. Prolongacion Javier Prado Mz M Lte. 23</p>
                        </div>
                    </label>

                    <input type="radio" id="barbadillo" name="location" value="Barbadillo">
                    <label class="w100" for="barbadillo">
                    <h4>Barbadillo</h4>
                    <div class="flex-row gap-5">
                            <i class="ri-map-pin-line"></i>
                            <p>Av. Prolongacion Javier Prado Mz M Lte. 23</p>
                        </div>
                    </label> 

                    <input type="radio" id="tiendamolina" name="location" value="la molina">
                    <label for="tiendamolina"><h4>La Molina</h4></label>

                    <input type="radio" id="Agustino 1" name="location" value="Agustino 1">
                    <label for="Agustino 1"><h4>Agustino 1</h4></label>

                    <input type="radio" id="Agustino 2" name="location" value="Agustino 2">
                    <label for="Agustino 2"><h4>Agustino 2</h4></label>

                    <input type="radio" id="Agustino 3" name="location" value="Agustino 3">
                    <label for="Agustino 3"><h4>Agustino 3</h4></label>

                    <input type="radio" id="Agustino 4" name="location" value="Agustino 4">
                    <label for="Agustino 4"><h4>Agustino 4</h4></label>

                    <input type="radio" id="Huachipa" name="location" value="Huachipa">
                    <label for="Huachipa"><h4>Huachipa</h4></label>

                    <input type="radio" id="Carapongo" name="location" value="Carapongo">
                    <label for="Carapongo"><h4>Carapongo</h4></label>

                    <input type="radio" id="Staclara2" name="location" value="Santa clara 2">
                    <label for="Staclara2"><h4>Santa Clara 2</h4></label>

                    <input type="radio" id="Staclara1" name="location" value="Santa clara 1">
                    <label for="Staclara1"><h4>Santa Clara 1</h4></label>

                    <input type="radio" id="San Gregorio" name="location" value="San Gregorio">
                    <label for="San Gregorio"><h4>San Gregorio</h4></label>

                    <input type="radio" id="El olivar" name="location" value="El olivar">
                    <label for="El olivar"><h4>El olivar</h4></label>

                    <input type="radio" id="San juan" name="location" value="San juan">
                    <label for="San juan"><h4>San Juan</h4></label>

                    <input type="radio" id="Horacio" name="location" value="Horacio">
                    <label for="Horacio"><h4>Horacio</h4></label>

                    <input type="radio" id="chosica" name="location" value="Chosica">
                    <label for="chosica"><h4>Chosica</h4></label>

                    <input type="radio" id="Huaycan 1" name="location" value="Huaycan 1">
                    <label for="Huaycan 1"><h4>Huaycan 1</h4></label>

                    <input type="radio" id="Huaycan 2" name="location" value="Huaycan 2">
                    <label for="Huaycan 2"><h4>Huaycan 2</h4></label>

                    <input type="radio" id="Amauta 1" name="location" value="Amauta 1">
                    <label for="Amauta 1"><h4>Amauta 1</h4></label>

                    <input type="radio" id="Amauta 2" name="location" value="Amauta 2">
                    <label for="Amauta 2"><h4>Amauta 2</h4></label>
                </div>
                `;
            }
        });

        nextStepBtn2.addEventListener('click', () => {
            const locationRadios = document.querySelectorAll('input[name="location"]');
            selectedLocation = Array.from(locationRadios).find(radio => radio.checked).value;
            sessionStorage.setItem('selectedLocation', selectedLocation);
            showStep(3);
            
            if (selectedDeliveryType === 'delivery') {
                if (selectedLocation === 'none') {
                    customMessage.innerHTML = `
                        <p>Entrega a domicilio no disponible en su distrito.</p>
                        <p>Utilizar la opción de Recojo en tu tienda más cercana.</p>
                        <button class="mgtp padding1 w100 brojo border20 colblanco bold" id="goBackBtn">Volver a la Selección</button>`;
                } else {
                    customMessage.innerHTML = `
                        <p>Estimado Cliente nuestro servicio de Delivery esta disponible en <b>${selectedLocation}</b></p>
                        <button class="mgtp padding1 w100 brojo border20 colblanco bold" id="acceptBtn">Empezar a Comprar</button>`;
                    acceptBtn = document.getElementById('acceptBtn'); // Asignación de la variable
                    acceptBtn.addEventListener('click', () => {
                        modal.style.display = 'none';
                        resultadoPersonalizado.style.display = 'block';
                        resultadoPersonalizado.innerHTML = `
                            <p>${selectedDeliveryType}</p>
                            <b>${selectedLocation}</b>`;
                    });
                }
            } else if (selectedDeliveryType === 'tienda') {
                customMessage.innerHTML = `
                    <p>¡Recoger en tienda disponible en ${selectedLocation}</p>
                    <button class="mgtp padding1 w100 brojo border20 colblanco bold" id="acceptBtn">Empezar a Comprar</button>`;
                acceptBtn = document.getElementById('acceptBtn'); // Asignación de la variable
                acceptBtn.addEventListener('click', () => {
                    modal.style.display = 'none';
                    resultadoPersonalizado.style.display = 'block';
                    resultadoPersonalizado.innerHTML = `
                        <p>${selectedDeliveryType}</p>
                        <b>${selectedLocation}</b>`;
                });
            }
            
            const goBackBtn = document.getElementById('goBackBtn');
            if (goBackBtn) {
                goBackBtn.addEventListener('click', () => {
                    showStep(1);
                });
            }
        });

        const showModalKey = 'showModal';
        if (!sessionStorage.getItem(showModalKey)) {
            modal.style.display = 'flex';
            showStep(1);
            sessionStorage.setItem(showModalKey, 'true');
        }

        setTimeout(() => {
            if (!sessionStorage.getItem(showModalKey)) {
                modal.style.display = 'flex';
                showStep(1);
                sessionStorage.setItem(showModalKey, 'true');
            }
        }, 2000); // 2000 milisegundos = 2 segundos