/* */
//formulario///
///
document.addEventListener("DOMContentLoaded", function () {
	const form = document.getElementById("checkout-form");
	const steps = form.getElementsByClassName("step");
	const popup = document.getElementById("popup");
	const popupContent = document.querySelector(".popup-content");
	let currentStep = 0;
  
	showStep(currentStep);
  
	function showStep(stepIndex) {
	  steps[currentStep].classList.remove("active");
	  currentStep = stepIndex;
	  steps[currentStep].classList.add("active");
	  updateButtons();
	}
  
	function updateButtons() {
	  const prevButton = steps[currentStep].querySelector(`#prev-step${currentStep + 1}`);
	  const nextButton = steps[currentStep].querySelector(`#next-step${currentStep + 1}`);
	  
	  if (prevButton) {
		prevButton.addEventListener("click", () => showStep(currentStep - 1));
	  }
	  
	  if (nextButton) {
		nextButton.addEventListener("click", () => {
		  if (validateStep(currentStep)) {
			showStep(currentStep + 1);
		  }
		});
	  }
	  
	  const finishButton = steps[currentStep].querySelector("#finish");
	  if (finishButton) {
		finishButton.addEventListener("click", () => {
		  if (validateStep(currentStep)) {
			showPopup();
		  }
		});
	  }
  
	  updateNextButtonState();
	}
  
	function validateStep(stepIndex) {
	  const inputs = steps[stepIndex].querySelectorAll("input, select");
	  let isValid = true;
  
	  inputs.forEach(input => {
		if (!input.value) {
		  isValid = false;
		}
	  });
  
	  return isValid;
	}
  
	function updateNextButtonState() {
	  const nextButton = steps[currentStep].querySelector(`#next-step${currentStep + 1}`);
	  if (nextButton) {
		nextButton.disabled = !validateStep(currentStep);
	  }
	}
    
    const nextStep2Button = document.getElementById("next-step2");
    const preciotortitaElement = document.getElementById("preciotortita");
    const distanciaSolesElement = document.getElementById("distancia-soles");
    const precioTotalElement = document.getElementById("preciototal");

    nextStep2Button.addEventListener("click", function() {
        // Obtener el valor numérico de los elementos y sumarlos
        const preciotortita = parseFloat(preciotortitaElement.textContent);
        const distanciaSoles = parseFloat(distanciaSolesElement.textContent.substring(2)); // Elimina el 'S/' y convierte a número
        const sumaTotal = preciotortita + distanciaSoles;

        // Mostrar el resultado en el elemento #preciototal
        precioTotalElement.textContent = sumaTotal.toFixed(2); // Mostrar el resultado con dos decimales
    });

	function showPopup() {
		
	  // en caso de texto
	  const nombreproducto = document.getElementById("nombreproducto").innerHTML;
	  const tamanotorta = document.getElementById("tamanotorta").innerHTML;
	  const preciototal = document.getElementById("preciototal").innerHTML;
	  // en caso de input
	  const nombre = document.getElementById("nombre").value;
	  const telefono = document.getElementById("telefono").value;
	  const email = document.getElementById("email").value;
	  const direccion = document.getElementById("direccion").value;
	  const referencia = document.getElementById("referencia").value;
	  const lat = document.getElementById("lat").value;
	  //const tipoComprobante = document.getElementById("tipo-comprobante").value;
	  //const tipoDocumento = document.getElementById("tipo-documento").value;
	  const numeroDocumento = document.getElementById("numero-documento").value;
	  const selectedPayment = document.querySelector("input[name='payment']:checked").value;
  
	  document.getElementById("popup-nombreproducto").textContent = nombreproducto;
	  document.getElementById("popup-tamanotorta").textContent = tamanotorta;
	  document.getElementById("popup-preciototal").textContent = preciototal;
	  document.getElementById("popup-nombre").textContent = nombre;
	  document.getElementById("popup-telefono").textContent = telefono;
	  document.getElementById("popup-email").textContent = email;
	  document.getElementById("popup-direccion").textContent = direccion;
	  document.getElementById("popup-referencia").textContent = referencia;
	  document.getElementById("popup-lat").textContent = lat;
	  //document.getElementById("popup-tipo-comprobante").textContent = tipoComprobante;
	  //document.getElementById("popup-tipo-documento").textContent = tipoDocumento;
	  document.getElementById("popup-numero-documento").textContent = numeroDocumento;
	  document.getElementById("popup-payment").textContent = selectedPayment
	  if (selectedPayment == 'yape') {
		// Obtén el elemento por su ID
		const elemento = document.getElementById("fondocambio");	
		// Agrega la clase al elemento
		elemento.classList.add('yape', 'colnegro');
		///////
		document.getElementById("qrimage").src = `https://tortaza.com.pe/Assets/tienda/images/qr/pago/998881052.png`;
		document.getElementById("metodopago").innerHTML =  `
		<img class="icon-circ" src="./img/yape-logo.png" alt="">
		<p class="normal tac">Ingresa a Yape desde tu celular y </br>escanéa este código QR</p>
		
		`;
		document.getElementById("numeropago").innerHTML =  `
		<p class="normal tac">ó ingresa este número</p>
		`;
		document.getElementById("numpago").innerHTML ="980852322"
		;
				
	  } else if (selectedPayment == 'deposito') {
		// Obtén el elemento por su ID
		const elemento = document.getElementById("fondocambio");	
		// Agrega la clase al elemento
		elemento.classList.add('bblanco', 'colnegro');
		///////
		document.getElementById("metodopago").innerHTML =  `
		<p><span class="bold">Depósito o Transferencia</span></p>
		<p>Paga vía depósito o Transferencia Bancaria</p>
		`;
		document.getElementById("numeropago").innerHTML =  `
		<b>Numero de Cuenta BCP</b>
		`;
		document.getElementById("numpago").innerHTML ="980852322";
	  } 
	  else  {
		// Obtén el elemento por su ID
		const elemento = document.getElementById("fondocambio");	
		// Agrega la clase al elemento
		elemento.classList.add('plin', 'colnegro');
		///////
		document.getElementById("qrimage").src = `https://tortaza.com.pe/Assets/tienda/images/qr/pago/998881052.png`;
		document.getElementById("metodopago").innerHTML =  `
		<img class="icon-circ" src="./img/plin-logo.png" alt="">
		<p class="normal tac">Ingresa a Plin desde tu celular y </br>escanéa este código QR</p>
		
		`;
		document.getElementById("numeropago").innerHTML =  `
		<p class="normal tac">ó ingresa este número</p>
		`;
		document.getElementById("numpago").innerHTML ="980852322"
		;


		document.getElementById("qrimage").src = `https://tortaza.com.pe/Assets/tienda/images/qr/pago/998881052.png`;
		
	  }
	  popup.style.display = "flex";
	}
  
	const checkboxes = document.querySelectorAll("input[type='checkbox']");
	checkboxes.forEach(checkbox => {
	  checkbox.addEventListener("change", updateNextButtonState);
	});
  
	const inputs = form.querySelectorAll("input, select");
	inputs.forEach(input => {
	  input.addEventListener("input", updateNextButtonState);
	});
  
	const sendWhatsappButton = document.getElementById("send-whatsapp");
	sendWhatsappButton.addEventListener("click", () => {
	  const message = generateWhatsAppMessage();
	  const encodedMessage = encodeURIComponent(message);
	  const whatsappNumber = "51989396941"; // Replace with your actual WhatsApp number
	  const whatsappUrl = `https://api.whatsapp.com/send/?phone=${whatsappNumber}&text=${encodedMessage}`;
	  window.open(whatsappUrl, "_blank");
	  $('.popup').fadeOut();
	});
  
	function generateWhatsAppMessage() {
	  const nombreproducto = document.getElementById("popup-nombreproducto").textContent;
	  const tamanotorta = document.getElementById("popup-tamanotorta").textContent;
	  const preciototal = document.getElementById("popup-preciototal").textContent;
	  const nombre = document.getElementById("popup-nombre").textContent;
	  const telefono = document.getElementById("popup-telefono").textContent;
	  const direccion = document.getElementById("popup-direccion").textContent;
	  const referencia = document.getElementById("popup-referencia").textContent;
	  const lat = document.getElementById("popup-lat").textContent;
	  //const tipoComprobante = document.getElementById("popup-tipo-comprobante").textContent;
	  //const tipoDocumento = document.getElementById("popup-tipo-documento").textContent;
	  const numeroDocumento = document.getElementById("popup-numero-documento").textContent;
	  const selectedPayment = document.getElementById("popup-payment").textContent;
  
	  const message = `¡Hola! Quiero hacer un pedido
	  \n\nDetalles del Pedido:
	  --------------------
	  *Cliente*
	  Nombre: *${nombre}*
	  Teléfono: *${telefono}*
	  --------------------
	  *DNI*
	  Número de Documento: *${numeroDocumento}*
	  --------------------
	  *Ubicación*
	  Dirección: *${direccion}*
	  Referencia: *${referencia}*
	  Coordenadas: *${lat}*
	  --------------------
	  *Producto*
	  *${nombreproducto}* *${tamanotorta}*
	  Precio total: s/ *${preciototal}*
	  --------------------
	  Quiero pagar con *${selectedPayment}*
	  --------------------
	  ¡Gracias!`;
	  return message;
	}
  });

 // copiar y pegar //
$(document).ready(function() {
	$('#copiar, #copia').click(function(){
		var btntxt = $(this).text();
		var copy = $(this).parent().find('.copy').text();
		var $temp = $("<input>");
		$("body").append($temp);
		$temp.val(copy).select();
		document.execCommand("copy");
		$temp.remove();
		$('.confirmation').hide().html( 'el numero' + '</b> Ha sido copiado al portapapeles').fadeIn(100).delay(800).fadeOut(200);
		$( '.main' ).trigger( "click" );
	});
	$('.main div').click(function(){
		var range = document.createRange();
		var selection = window.getSelection();
		range.selectNodeContents(this);
		selection.removeAllRanges();
		selection.addRange(range);
	});
});